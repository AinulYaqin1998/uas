package com.rahmat.app.base;

public class MyClass {
}
