package com.rahmat.app.samplecrudkotlin.di

import javax.inject.Qualifier

/**
 * Created by muhrahmatullah on 26/09/18.
 */
@Qualifier
@Retention
annotation class DbName {
}