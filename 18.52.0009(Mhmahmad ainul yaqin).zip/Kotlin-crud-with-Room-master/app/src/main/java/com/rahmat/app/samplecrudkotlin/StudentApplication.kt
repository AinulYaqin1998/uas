package com.rahmat.app.samplecrudkotlin

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Created by muhrahmatullah on 27/08/18.
 */
@HiltAndroidApp
class StudentApplication : Application()